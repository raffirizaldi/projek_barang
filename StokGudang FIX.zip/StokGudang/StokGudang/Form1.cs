﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace StokGudang
{
    public partial class Form1 : Form
    {
        List<Barang> listBarang = new List<Barang> ();
        public int barangID = 0;
        public Form1()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadData();
            RefreshDateGrid();
            SaveData();
        }

        private void SaveData()
        {   
            if (File.Exists("data.csv"))
                File.Delete("data.csx");
            StreamWriter sw = new StreamWriter("data.csv");
            sw.WriteLine("#barangID, barangNama, barangBerat, barangIsi");
            foreach (Barang getBarang in listBarang)
                sw.WriteLine(getBarang.ID.ToString()+","+ getBarang.Nama.ToString()+","+ getBarang.Berat.ToString()+ " , "+getBarang.Isi.ToString()+ "");
            sw.Close();
        }

        private void LoadData()
        {
            if (File.Exists("data.csv"))
            {
                StreamReader sr = new StreamReader("data.csv");
                string line = sr.ReadLine();
                while (line != null)
                {
                    if (!line.Contains("#"))
                    {
                        string[] strSplit = line.Split(',');
                        int id = int.Parse(strSplit[0]);
                        string nama = strSplit[1];
                        int berat = int.Parse(strSplit[2]);
                        int isi = int.Parse(strSplit[3]); 
                        Barang newBarang= new Barang();
                        newBarang.IsiBarang(id, nama, berat, isi);
                        listBarang.Add(newBarang);
                    }
                    line = sr.ReadLine();
                }
                sr.Close();
            }
        }

        private void RefreshDateGrid()
        {
            dataGridView1.Rows.Clear ();
            foreach(Barang getBarang in listBarang)
            {
                string[] newRow = { "", "", "", ""};
                newRow[0] = getBarang.ID.ToString();
                newRow[1] = getBarang.Nama;
                newRow[2] = getBarang.Berat.ToString();
                newRow[3] = getBarang.Isi.ToString();
                dataGridView1 .Rows.Add (newRow);
            }
        }
        private int GetFreeID()
        {
            int nowID = 0;
            while (true)
            {
                bool adaYgSama = false;
                foreach (Barang checkBarang in listBarang)
                {
                    if (checkBarang.ID == nowID)
                        adaYgSama = true;
                }
                if (adaYgSama)
                    nowID += 1;
                else
                    break;
            }
            return nowID;
        }
        

        private Barang SelectBarang()
        {
            int getID = 0;
            for (int i = 0; i < dataGridView1.Rows.Count; i += 1)
            {
                if (dataGridView1.Rows[i].Selected)
                {
                    getID = int.Parse(dataGridView1.Rows[i].Cells[0].Value.ToString());

                    break;
                }
            }
            Barang getBarang= new Barang();
            foreach (Barang checkBarang in listBarang)
            {
                if (checkBarang.ID == getID)
                    getBarang = checkBarang;
            }
            return getBarang;
        }

        private void btnTambahDus_Click(object sender, EventArgs e)
        {
            Barang barangBaru = new Barang();
            barangID = GetFreeID();
            barangBaru.IsiBarang(barangID, txtNamaBarang.Text, (int)numBeratBarang.Value, (int)numIsiBarang.Value);
            listBarang.Add(barangBaru);
            RefreshDateGrid();
            SaveData();
        }
        private void btnHapusDus_Click(object sender, EventArgs e)
        {
            Barang getBarang= SelectBarang();
            if (listBarang.Contains (getBarang))
                listBarang.Remove (getBarang);
            RefreshDateGrid();
            SaveData();
        }

        private void btnEditDus_Click(object sender, EventArgs e)
        {
            Barang getBarang = SelectBarang();
            getBarang.EditBarang(textEditBarangNama.Text, (int)numEditBarangBerat.Value, (int)numEditBarangIsi.Value);
            RefreshDateGrid();
            SaveData();
            groupBox3.Enabled=false;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            Barang getBarang = SelectBarang();
            groupBox3.Enabled = true;
            textEditBarangNama.Text = getBarang.Nama;
            numEditBarangBerat.Value = getBarang.Berat;
            numEditBarangIsi.Value = getBarang.Isi;
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
