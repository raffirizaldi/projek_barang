﻿
namespace StokGudang
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnTambahBarang = new System.Windows.Forms.Button();
            this.numIsiBarang = new System.Windows.Forms.NumericUpDown();
            this.lblIsi = new System.Windows.Forms.Label();
            this.numBeratBarang = new System.Windows.Forms.NumericUpDown();
            this.lblBerat = new System.Windows.Forms.Label();
            this.lblNama = new System.Windows.Forms.Label();
            this.txtNamaBarang = new System.Windows.Forms.TextBox();
            this.lblNamaGudang = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnHapusBarang = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnEditBarang = new System.Windows.Forms.Button();
            this.numEditBarangIsi = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.numEditBarangBerat = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textEditBarangNama = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numIsiBarang)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numBeratBarang)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numEditBarangIsi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numEditBarangBerat)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnTambahBarang);
            this.groupBox1.Controls.Add(this.numIsiBarang);
            this.groupBox1.Controls.Add(this.lblIsi);
            this.groupBox1.Controls.Add(this.numBeratBarang);
            this.groupBox1.Controls.Add(this.lblBerat);
            this.groupBox1.Controls.Add(this.lblNama);
            this.groupBox1.Controls.Add(this.txtNamaBarang);
            this.groupBox1.Location = new System.Drawing.Point(18, 105);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Size = new System.Drawing.Size(532, 297);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tambah Barang";
            // 
            // btnTambahBarang
            // 
            this.btnTambahBarang.Location = new System.Drawing.Point(188, 216);
            this.btnTambahBarang.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnTambahBarang.Name = "btnTambahBarang";
            this.btnTambahBarang.Size = new System.Drawing.Size(336, 53);
            this.btnTambahBarang.TabIndex = 6;
            this.btnTambahBarang.Text = "Tambah Barang";
            this.btnTambahBarang.UseVisualStyleBackColor = true;
            this.btnTambahBarang.Click += new System.EventHandler(this.btnTambahDus_Click);
            // 
            // numIsiBarang
            // 
            this.numIsiBarang.Location = new System.Drawing.Point(188, 149);
            this.numIsiBarang.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.numIsiBarang.Maximum = new decimal(new int[] {
            999999999,
            0,
            0,
            0});
            this.numIsiBarang.Name = "numIsiBarang";
            this.numIsiBarang.Size = new System.Drawing.Size(336, 31);
            this.numIsiBarang.TabIndex = 5;
            // 
            // lblIsi
            // 
            this.lblIsi.AutoSize = true;
            this.lblIsi.Location = new System.Drawing.Point(36, 152);
            this.lblIsi.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblIsi.Name = "lblIsi";
            this.lblIsi.Size = new System.Drawing.Size(33, 25);
            this.lblIsi.TabIndex = 4;
            this.lblIsi.Text = "Isi";
            // 
            // numBeratBarang
            // 
            this.numBeratBarang.Location = new System.Drawing.Point(188, 105);
            this.numBeratBarang.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.numBeratBarang.Maximum = new decimal(new int[] {
            999999999,
            0,
            0,
            0});
            this.numBeratBarang.Name = "numBeratBarang";
            this.numBeratBarang.Size = new System.Drawing.Size(336, 31);
            this.numBeratBarang.TabIndex = 3;
            // 
            // lblBerat
            // 
            this.lblBerat.AutoSize = true;
            this.lblBerat.Location = new System.Drawing.Point(36, 108);
            this.lblBerat.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBerat.Name = "lblBerat";
            this.lblBerat.Size = new System.Drawing.Size(131, 25);
            this.lblBerat.TabIndex = 2;
            this.lblBerat.Text = "Berat (gram)";
            // 
            // lblNama
            // 
            this.lblNama.AutoSize = true;
            this.lblNama.Location = new System.Drawing.Point(36, 65);
            this.lblNama.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNama.Name = "lblNama";
            this.lblNama.Size = new System.Drawing.Size(143, 25);
            this.lblNama.TabIndex = 1;
            this.lblNama.Text = "Nama Barang";
            // 
            // txtNamaBarang
            // 
            this.txtNamaBarang.Location = new System.Drawing.Point(188, 60);
            this.txtNamaBarang.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtNamaBarang.Name = "txtNamaBarang";
            this.txtNamaBarang.Size = new System.Drawing.Size(334, 31);
            this.txtNamaBarang.TabIndex = 0;
            // 
            // lblNamaGudang
            // 
            this.lblNamaGudang.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblNamaGudang.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F);
            this.lblNamaGudang.Location = new System.Drawing.Point(0, 0);
            this.lblNamaGudang.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNamaGudang.Name = "lblNamaGudang";
            this.lblNamaGudang.Size = new System.Drawing.Size(1257, 100);
            this.lblNamaGudang.TabIndex = 1;
            this.lblNamaGudang.Text = "Stok Barang";
            this.lblNamaGudang.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnHapusBarang);
            this.groupBox2.Controls.Add(this.dataGridView1);
            this.groupBox2.Location = new System.Drawing.Point(560, 105);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox2.Size = new System.Drawing.Size(669, 603);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "List Barang";
            // 
            // btnHapusBarang
            // 
            this.btnHapusBarang.Location = new System.Drawing.Point(20, 526);
            this.btnHapusBarang.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnHapusBarang.Name = "btnHapusBarang";
            this.btnHapusBarang.Size = new System.Drawing.Size(633, 55);
            this.btnHapusBarang.TabIndex = 1;
            this.btnHapusBarang.Text = "Hapus Barang";
            this.btnHapusBarang.UseVisualStyleBackColor = true;
            this.btnHapusBarang.Click += new System.EventHandler(this.btnHapusDus_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column5,
            this.Column1,
            this.Column2,
            this.Column3});
            this.dataGridView1.Location = new System.Drawing.Point(20, 34);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(633, 473);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Column5
            // 
            this.Column5.HeaderText = "ID";
            this.Column5.MinimumWidth = 6;
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.Width = 28;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Nama Barang";
            this.Column1.MinimumWidth = 6;
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 170;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Berat";
            this.Column2.MinimumWidth = 6;
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 80;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Isi";
            this.Column3.MinimumWidth = 6;
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Width = 34;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnEditBarang);
            this.groupBox3.Controls.Add(this.numEditBarangIsi);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.numEditBarangBerat);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.textEditBarangNama);
            this.groupBox3.Enabled = false;
            this.groupBox3.Location = new System.Drawing.Point(18, 411);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox3.Size = new System.Drawing.Size(532, 297);
            this.groupBox3.TabIndex = 9;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Edit Barang";
            // 
            // btnEditBarang
            // 
            this.btnEditBarang.Location = new System.Drawing.Point(188, 206);
            this.btnEditBarang.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnEditBarang.Name = "btnEditBarang";
            this.btnEditBarang.Size = new System.Drawing.Size(336, 53);
            this.btnEditBarang.TabIndex = 6;
            this.btnEditBarang.Text = "Edit Barang";
            this.btnEditBarang.UseVisualStyleBackColor = true;
            this.btnEditBarang.Click += new System.EventHandler(this.btnEditDus_Click);
            // 
            // numEditBarangIsi
            // 
            this.numEditBarangIsi.Location = new System.Drawing.Point(188, 141);
            this.numEditBarangIsi.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.numEditBarangIsi.Maximum = new decimal(new int[] {
            999999999,
            0,
            0,
            0});
            this.numEditBarangIsi.Name = "numEditBarangIsi";
            this.numEditBarangIsi.Size = new System.Drawing.Size(336, 31);
            this.numEditBarangIsi.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(36, 144);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 25);
            this.label2.TabIndex = 4;
            this.label2.Text = "Isi";
            // 
            // numEditBarangBerat
            // 
            this.numEditBarangBerat.Location = new System.Drawing.Point(188, 97);
            this.numEditBarangBerat.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.numEditBarangBerat.Maximum = new decimal(new int[] {
            999999999,
            0,
            0,
            0});
            this.numEditBarangBerat.Name = "numEditBarangBerat";
            this.numEditBarangBerat.Size = new System.Drawing.Size(336, 31);
            this.numEditBarangBerat.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(36, 100);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(131, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Berat (gram)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(36, 57);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(143, 25);
            this.label4.TabIndex = 1;
            this.label4.Text = "Nama Barang";
            // 
            // textEditBarangNama
            // 
            this.textEditBarangNama.Location = new System.Drawing.Point(188, 52);
            this.textEditBarangNama.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textEditBarangNama.Name = "textEditBarangNama";
            this.textEditBarangNama.ShortcutsEnabled = false;
            this.textEditBarangNama.Size = new System.Drawing.Size(334, 31);
            this.textEditBarangNama.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1257, 725);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.lblNamaGudang);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Stok Gudang";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numIsiBarang)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numBeratBarang)).EndInit();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numEditBarangIsi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numEditBarangBerat)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnTambahBarang;
        private System.Windows.Forms.NumericUpDown numIsiBarang;
        private System.Windows.Forms.Label lblIsi;
        private System.Windows.Forms.NumericUpDown numBeratBarang;
        private System.Windows.Forms.Label lblBerat;
        private System.Windows.Forms.Label lblNama;
        private System.Windows.Forms.TextBox txtNamaBarang;
        private System.Windows.Forms.Label lblNamaGudang;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnHapusBarang;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnEditBarang;
        private System.Windows.Forms.NumericUpDown numEditBarangIsi;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown numEditBarangBerat;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textEditBarangNama;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
    }
}

