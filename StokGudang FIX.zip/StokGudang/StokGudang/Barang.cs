﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StokGudang
{
    public class Barang
    {
        private string nama;
        private int berat;
        private int isi;
        private int id;

        public int ID{ get => id;}
        public string Nama { get => nama;}
        public int Berat { get => berat; }
        public int Isi { get => isi;}

        public void EditBarang(string getNama, int getBerat, int getIsi)
        {
            this.nama = getNama;
            this.berat = getBerat;
            this.isi = getIsi;
            
        }

        public void IsiBarang(int getId, string getNama, int getBerat, int getIsi)
        {
            this.id = getId;
            this.nama = getNama;
            this.berat = getBerat;
            this.isi = getIsi;
            
        }

        internal void IsiBarang(object getID, string text, int value1, int value2)
        {
            throw new NotImplementedException();
        }
    }
}